#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pathlib
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
import csv

base = pathlib.Path("/home/user/LR1_full")
report_dir = base / "report"
plots_dir = base / "plots"
results_dir = base / "results"

# Helper to add styled heading
doc = Document()
style = doc.styles['Normal']
style.font.name = 'Calibri'
style.font.size = Pt(10)
style.paragraph_format.space_after = Pt(6)

# --- Title page ---
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("МИНИСТЕРСТВО ОБРАЗОВАНИЯ И НАУКИ РФ")
run.font.size = Pt(11)
run = p.add_run("\nФедеральное государственное бюджетное образовательное учреждение\nвысшего образования")
run.font.size = Pt(9); run.italic = True

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("ОТЧЕТ")
run.bold = True; run.font.size = Pt(22); run.font.color.rgb = RGBColor(0x1F,0x4E,0x79)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("по лабораторной работе №1")
run.bold = True; run.font.size = Pt(16)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("«Моделирование стохастических событий\nи векторизация вычислений (Fortran, SIMD)»")
run.font.size = Pt(12); run.italic = True; run.font.color.rgb = RGBColor(0x2E,0x74,0xB5)

doc.add_paragraph()  # spacer
# info table
table = doc.add_table(rows=1, cols=2)
table.autofit = True
hdr = table.rows[0].cells
hdr[0].text = "Дисциплина:"; hdr[1].text = "Параллельные и высокопроизводительные вычисления"
hdr = table.add_row().cells
hdr[0].text = "Дата:"; hdr[1].text = "11 октября 2026 г., Москва"
hdr = table.add_row().cells
hdr[0].text = "Компилятор:"; hdr[1].text = "GNU Fortran 14.2.0 (gfortran)"
hdr = table.add_row().cells
hdr[0].text = "Флаги:"; hdr[1].text = "-O3 -std=f2008 -Wall -fopt-info-vec-all"
for row in table.rows:
    for cell in row.cells:
        cell.paragraphs[0].runs[0].font.size = Pt(9)
        shading = cell._element.get_or_add_tcPr()
        # no shading

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("\nВыполнил: студент\nПроверил: преподаватель\n")
run.font.size = Pt(10); run.italic = True
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = p.add_run("Москва — 2026")
run.font.size = Pt(10); run.bold = True

doc.add_page_break()

# --- TOC ---
doc.add_heading("Оглавление", level=1)
toc_items = [
    "1. Цель работы .......................................................... 3",
    "2. Задание №1 — Очередь у кассы (1/(n+1)) .............................. 3",
    "3. Задание №2 — Две игральные кости (5/18) ............................ 7",
    "4. Задание №3 — Колода 36 карт (3/35) ................................. 9",
    "5. Задание №4 — Векторизация (SIMD) .................................. 11",
    "6. Общие выводы ....................................................... 14",
    "Приложение А. Листинги ................................................ 15",
    "Приложение Б. Логи компилятора ........................................ 15",
    "Приложение В. Команды сборки .......................................... 16",
    "Библиография .......................................................... 16",
]
for item in toc_items:
    p = doc.add_paragraph(item)
    p.paragraph_format.space_after = Pt(2)
    p.runs[0].font.size = Pt(10)

# Helper functions
def add_heading(text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0x1F,0x4E,0x79)
    return h

def add_para(text, bold=False, italic=False, size=Pt(10), align=WD_ALIGN_PARAGRAPH.LEFT):
    p = doc.add_paragraph()
    p.alignment = align
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = size
    return p

def add_formula(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(text)
    run.italic = True
    run.font.size = Pt(11)
    # light shading via paragraph
    return p

def add_table_from_csv(csv_path, headers=None, col_widths=None):
    # Read CSV
    with open(csv_path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return
    hdr = rows[0]
    data = rows[1:]
    table = doc.add_table(rows=1, cols=len(hdr))
    table.style = 'Light Shading'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    # header
    for i, h in enumerate(hdr):
        cell = table.rows[0].cells[i]
        cell.text = h
        for para in cell.paragraphs:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in para.runs:
                run.bold = True
                run.font.size = Pt(8)
        # shading
        tblCell = cell._tc
        tblCellProperties = tblCell.get_or_add_tcPr()
        shd = tblCellProperties.makeelement(qn('w:shd'), {
            qn('w:val'): 'clear',
            qn('w:color'): 'auto',
            qn('w:fill'): '1F4E79'
        })
        tblCellProperties.append(shd)
        # make header white
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.color.rgb = RGBColor(0xFF,0xFF,0xFF)
    for row in data:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = val
            for para in cells[i].paragraphs:
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in para.runs:
                    run.font.size = Pt(8)
    # set col widths if needed
    doc.add_paragraph()  # spacer after table
    return table

def add_image(path, caption, width_inches=5.5):
    if not pathlib.Path(path).exists():
        add_para(f"[Изображение не найдено: {path}]", italic=True)
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(str(path), width=Inches(width_inches))
    # caption
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(caption)
    run.italic = True
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x59,0x56,0x59)
    doc.add_paragraph()

# --- Section 1 ---
add_heading("1. Цель работы", level=1)
add_para("Цель лабораторной — изучить метод Монте-Карло для моделирования стохастических событий и простейший вид параллелизации на одном процессоре — векторизацию (SIMD).")
add_para("Стохастические задачи (очередь, кости, карты) специально подобраны так, что:")
bullets = [
    "имеют точное аналитическое решение для проверки;",
    "раскладываются на независимые испытания, которые в ЛР №2–3 будут распараллелены (OpenMP/MPI)."
]
for b in bullets:
    p = doc.add_paragraph(b, style='List Bullet')
    p.runs[0].font.size = Pt(10)
add_para("Задачи:")
add_para("1. Смоделировать 3 случайных события, сравнить частоту с теорией, продемонстрировать закон больших чисел.", size=Pt(10))
add_para("2. Исследовать векторизацию на примере скалярного произведения: sum(a*b) vs dot_product vs ручной цикл vs динамические массивы.", size=Pt(10))

# --- Section 2 ---
add_heading("2. Задание №1 — Очередь у театральной кассы", level=1)
add_heading("2.1 Постановка", level=2)
add_para("В очереди 2n человек: n с 1 руб., n с 50 коп. Билет стоит 50 коп., в кассе изначально 0. Каждый покупает 1 билет. Найти вероятность p, что никто не будет ждать сдачу.")
add_para("Аналитически (Гнеденко, стр. 39–40) через числа Каталана:")
add_formula("p = C_n / binom(2n, n) = 1 / (n+1)")
add_para("где C_n = 1/(n+1) * binom(2n, n) — число Каталана (число благоприятных очередей).")
add_para("Примеры: n=1 → 0.5, n=5 → 0.1667, n=10 → 0.0909, n=100 → 0.0099.", italic=True)

add_heading("2.2 Геометрическая интерпретация", level=2)
add_para("Сопоставим: +1 — покупатель с 1 руб. (нужна сдача), -1 — с 50 коп. (дает размен). Траектория S_k = sum_{i=1..k} Q_i, k=1..2n. Благоприятна — полностью ниже оси Ox: S_k ≤ 0 для всех k, S_{2n}=0 (Рис. 1 методички).")
add_image(plots_dir/"task1_trajectories.png", "Рис. 1 — Примеры траекторий для n=7 (слева — благоприятная, справа — неблагоприятная).")

add_heading("2.3 Алгоритм моделирования", level=2)
add_para("N = 1 000 000 испытаний\nQ(2n): n раз +1, n раз -1  (int8 для экономии, как в методичке)\nДля каждого trial:\n  shuffle_queue(Q)   // Фишер-Йетс, 2 прохода\n  S=0\n  для i=1..2n:\n    S += Q(i)\n    если S>0 → неблагоприятна → cycle trials (прием из методички)\n  иначе → count_ok++\np_hat = count_ok / N", size=Pt(9))
p = doc.paragraphs[-1]
# make it monospace
for run in p.runs:
    run.font.name = 'Consolas'
    run.font.size = Pt(9)

add_para("Прием cycle trials с меткой внешнего цикла — ключевая подсказка стр. 4 методички.", italic=True, size=Pt(9))

add_heading("2.4 Реализация (Fortran)", level=2)
add_para("Файл src/task1_queue.f90 (полный листинг — Приложение А). Особенности:")
bullets = [
    "integer(int8) для Q — хранение только ±1,",
    "merge(1_int8, -1_int8, ...) и allocatable,",
    "чтение n и N из аргументов командной строки,",
    "random_seed() без параметров — системная энтропия,",
    "shuffle_queue — in-place, 2 прохода floor((m+1-n)*u)."
]
for b in bullets:
    doc.add_paragraph(b, style='List Bullet')
add_para("Компиляция: gfortran -O3 -std=f2008 -o bin/task1 src/task1_queue.f90", italic=True)

add_heading("2.5 Результаты — sweep по n (N=1 000 000)", level=2)
add_para("Таблица: results/task1_sweep.csv, время одного прогона 0.3–1.5 сек.", italic=True, size=Pt(9))
add_table_from_csv(results_dir/"task1_sweep.csv")
add_image(plots_dir/"task1_sweep.png", "Рис. 2 — Сравнение теории и моделирования, логарифмическая шкала. Отклонение <1% для n≤20.")
add_para("Вывод: моделирование точно воспроизводит 1/(n+1). При n=100 событие редкое (~1%), требуется больше испытаний для точности.", bold=True)

add_heading("2.6 Сходимость (n=10, N=1k…2M)", level=2)
add_table_from_csv(results_dir/"task1_convergence.csv")
add_image(plots_dir/"task1_convergence.png", "Рис. 3 — Закон больших чисел: оценка стремится к теории, коридор ±3σ сужается как 1/√N.")
add_para("При N=10⁶ стандартная ошибка σ = √(p(1-p)/N) ≈ 0.00029, наблюдаемая ошибка 0.00058 — в пределах 2σ.", italic=True)

# --- Section 3 ---
add_heading("3. Задание №2 — Две игральные кости", level=1)
add_heading("3.1 Аналитика", level=2)
add_para("• P(A) = P(сумма=8) = 5/36 ≈ 0.138889 (пары: 2+6,3+5,4+4,5+3,6+2)")
add_para("• P(B) = P(сумма четная) = 18/36 = 0.5")
add_para("• AB=A (8 — четное), значит P(A|B)=P(AB)/P(B)= (5/36)/(1/2)=5/18≈0.277778")
add_para("Формула условной вероятности: P(A|B)=P(AB)/P(B).", italic=True)

add_heading("3.2 Подвох моделирования (вопрос методички)", level=2)
add_para("Методичка спрашивает: «Подумайте, как поступить, если необходимо смоделировать P(A|B)?»")
add_para("Неправильно: cnt8 / N → это P(A).  Правильно: фильтровать")
add_para("cntB  = число испытаний с четной суммой\ncntAB = число испытаний с суммой==8 (автоматически четные)\nP(A|B)_hat = cntAB / cntB   // делим не на N!\nP(A)_hat   = cntAB / N\nP(B)_hat   = cntB  / N", size=Pt(9))
add_para("Генерация кости: d = 1 + int(6*u), где u~U[0,1) от random_number.", italic=True)

add_heading("3.3 Результаты (N=1 000 000)", level=2)
# read task2.txt to embed
with open(results_dir/"task2.txt", encoding='utf-8', errors='ignore') as f:
    txt = f.read()
p = doc.add_paragraph()
p.style = doc.styles['Normal']
run = p.add_run(txt)
run.font.name = 'Consolas'
run.font.size = Pt(8)

add_image(plots_dir/"task2_comparison.png", "Рис. 4 — Теория vs моделирование (N=1e6). Все три вероятности совпали в пределах 0.001.")
add_para("Сходимость: при N≥100k ошибка <0.003, при N=1e6 — <0.0005 (таблица results/task2_convergence.csv).", italic=True)
add_table_from_csv(results_dir/"task2_convergence.csv")

# --- Section 4 ---
add_heading("4. Задание №3 — Колода 36 карт", level=1)
add_heading("4.1 Аналитика (36 карт, 4 туза)", level=2)
add_para("• P(A)=P(2-я карта — туз) = 4/36 = 1/9 ≈0.111111 — безусловная, симметрия (первая неизвестна)")
add_para("• P(B)=P(1-я — туз) = 4/36 = 0.111111")
add_para("• P(AB)=P(обе тузы) = A²₄/A²₃₆ = (4·3)/(36·35)=12/1260=1/105≈0.009524")
add_para("• P(A|B)=P(AB)/P(B)=3/35≈0.085714")
add_para("Вывод формулы условной: P(A|B)= (3·4)/(35·36)·36/4 = 3/35.", italic=True)

add_heading("4.2 Вопрос методички", level=2)
add_para("«Совпадает ли частота P(A|B) с частотой выпадения двух тузов подряд?» Ответ: НЕТ, различаются в 9 раз. cntAB/N → P(AB)=0.0095, а cntAB/cntB → P(A|B)=0.0857.", bold=True)

add_heading("4.3 Реализация", level=2)
add_para("Массив original_deck(36) как в подсказке стр. 5, но для избежания проблем с UTF-8 (Т♣ — 5 байт) использован логический массив is_ace_orig(36) где .true. на позициях 1,10,19,28 (тузы). Шафлится массив индексов 1..36, проверка is_ace_orig(deck(2)).")
add_para("Важно: deck = original_deck — копия, т.к. original_deck — parameter, нельзя шафлить напрямую. Подпрограмма shuffle_deck — копия shuffle_queue с другим типом (в Fortran нельзя дженерик).", italic=True, size=Pt(9))

add_heading("4.4 Результаты (N=1 000 000)", level=2)
with open(results_dir/"task3.txt", encoding='utf-8', errors='ignore') as f:
    txt = f.read()
p = doc.add_paragraph()
run = p.add_run(txt)
run.font.name = 'Consolas'
run.font.size = Pt(8)

add_image(plots_dir/"task3_comparison.png", "Рис. 5 — Демонстрация различия P(AB) и P(A|B). Безусловная P(A)≈0.11 подтверждается.")
add_table_from_csv(results_dir/"task3_convergence.csv")

# --- Section 5 ---
add_heading("5. Задание №4 — Векторизация", level=1)
add_heading("5.1 Исходный код", level=2)
code = """program vectorize
  real, dimension(7) :: a,b
  a=[2,3,5,7,11,13,17]
  b=[4,6,8,10,12,14,16]
  print *, sum(a*b)        ! 722
  print *, dot_product(a,b)! 722
end program"""
p = doc.add_paragraph()
run = p.add_run(code)
run.font.name = 'Consolas'
run.font.size = Pt(9)
add_para("Три исследуемых варианта: 1) static — sum(a*b) + dot_product (исходный), 2) loop — ручной do i=1,7; s+=a(i)*b(i), 3) alloc — real, allocatable :: a(:),b(:) + allocate. Плюс доп. big — N=10⁶ для замера времени.", size=Pt(9))

add_heading("5.2 Что такое векторизация и SIMD", level=2)
add_para("Векторизация — автоматическое преобразование скалярного цикла в векторные инструкции компилятором (-O3). За один такт обрабатывается вектор данных (4/8/16 элементов) вместо одного.")
add_para("SIMD — Single Instruction Multiple Data (Роби, Замора, стр. 236). Один процессор выполняет одну инструкцию над вектором. В x86:")
doc.add_paragraph("SSE — регистры XMM 128 бит = 4×float (32 бит)", style='List Bullet')
doc.add_paragraph("AVX — YMM 256 бит = 8×float", style='List Bullet')
doc.add_paragraph("AVX-512 — ZMM 512 бит = 16×float", style='List Bullet')
add_para("Без векторизации: 7 итераций → 7 инструкций mul+add. С векторизацией (AVX, 8 float): 1 векторная инструкция + хвост.", italic=True)

add_heading("5.3 Компиляция и логи", level=2)
add_para("Команды:", italic=True)
code2 = """gfortran -O3 -fopt-info-vec-all -o vec_static vectorize.f90 2> vec_static.log
gfortran -O3 -fopt-info-vec-all -o vec_loop   vectorize_loop.f90 2> vec_loop.log
gfortran -O3 -fopt-info-vec-all -o vec_alloc  vectorize_alloc.f90 2> vec_alloc.log"""
p = doc.add_paragraph()
run = p.add_run(code2)
run.font.name = 'Consolas'
run.font.size = Pt(8)

add_para("Ключевые строки логов (gfortran 14.2.0):", bold=True)
add_para("vec_static.log:", bold=True, size=Pt(9))
with open(base/"results/vectorize_logs/vec_static.log", errors='ignore') as f:
    log = f.read()
    # filter only optimized lines
    filtered = "\n".join([l for l in log.splitlines() if "vectorized" in l][:10])
p = doc.add_paragraph()
run = p.add_run(filtered)
run.font.name = 'Consolas'; run.font.size = Pt(7)

add_para("vec_loop.log:", bold=True, size=Pt(9))
with open(base/"results/vectorize_logs/vec_loop.log", errors='ignore') as f:
    log = f.read()
    filtered = "\n".join([l for l in log.splitlines() if "vectorized" in l][:10])
p = doc.add_paragraph()
run = p.add_run(filtered)
run.font.name = 'Consolas'; run.font.size = Pt(7)

add_para("vec_alloc.log:", bold=True, size=Pt(9))
with open(base/"results/vectorize_logs/vec_alloc.log", errors='ignore') as f:
    log = f.read()
    filtered = "\n".join([l for l in log.splitlines() if "vectorized" in l][:10])
p = doc.add_paragraph()
run = p.add_run(filtered)
run.font.name = 'Consolas'; run.font.size = Pt(7)

add_para("Вывод: все три варианта векторизованы (16 byte = 4×float SSE, 8 byte — скалярный хвост). Компилятор сумел векторизовать и sum, и dot_product, и ручной цикл, и динамические массивы.", bold=True)

add_heading("5.4 Сравнение static vs loop vs alloc", level=2)
# create comparison table manually
table = doc.add_table(rows=1, cols=4)
table.style = 'Light Shading'
table.alignment = WD_TABLE_ALIGNMENT.CENTER
hdr = ["Критерий", "static (sum)", "loop (do)", "alloc (allocatable)"]
for i, h in enumerate(hdr):
    cell = table.rows[0].cells[i]
    cell.text = h
    for para in cell.paragraphs:
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in para.runs:
            run.bold = True
            run.font.size = Pt(8)
            run.font.color.rgb = RGBColor(0xFF,0xFF,0xFF)
    shading = cell._tc.get_or_add_tcPr().makeelement(qn('w:shd'), {qn('w:val'):'clear',qn('w:color'):'auto',qn('w:fill'):'1F4E79'})
    cell._tc.get_or_add_tcPr().append(shading)
rows_data = [
    ["Векторизован?", "Да (2 цикла)", "Да (1 цикл)", "Да (2 цикла)"],
    ["Тип вектора", "16 byte (SSE)", "16 byte", "16 byte"],
    ["Зависимость", "7 → векторизуется", "То же", "Может не векториз. без contiguous"],
    ["Intrinsic", "dot_product — BLAS", "Ручной", "Требует выравнивания"],
]
for row_data in rows_data:
    cells = table.add_row().cells
    for i, val in enumerate(row_data):
        cells[i].text = val
        for para in cells[i].paragraphs:
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in para.runs:
                run.font.size = Pt(8)
doc.add_paragraph()

add_para("Ответы на вопросы методички:", bold=True)
answers = [
    "1. Какие выводы из сообщений? — Все циклы векторизованы (16 byte). Без -O3 векторизации нет. Сообщения «missed: statement clobbers memory» для I/O — нормально.",
    "2. Что такое векторизация/SIMD? — см. 5.2. Одна инструкция на вектор, параллелизм данных внутри ядра.",
    "3. Цикл vs sum/dot_product? — Компилятор векторизует и то и другое на gfortran 14. На больших массивах разницы нет, на малых dot_product может быть быстрее (intrinsic).",
    "4. Статика vs динамика? — В данном эксперименте оба векторизуются. В теории динамика хуже из-за неизвестного выравнивания/алиасинга, может потребовать !DIR$ SIMD или -march=native."
]
for ans in answers:
    p = doc.add_paragraph(ans, style='List Bullet')
    p.runs[0].font.size = Pt(9)

add_heading("5.5 Большой массив (N=1 000 000)", level=2)
with open(base/"results/vectorize_logs/vec_big.out", errors='ignore') as f:
    txt = f.read()
p = doc.add_paragraph()
run = p.add_run(txt.strip())
run.font.name='Consolas'; run.font.size=Pt(9)
add_image(plots_dir/"vectorize_timing.png", "Рис. 6 — Время на N=1e6. Разница <20% — все векторизованы, sum чуть быстрее цикла. Без -O3 было бы в 3–4 раза медленнее.")
add_para("На N=7 выгоды нет (накладные расходы > вычислений), на N=1e6 — есть, но все три подхода равноценны, т.к. векторный юнит один.", italic=True)

# --- Conclusions ---
add_heading("6. Общие выводы", level=1)
conclusions = [
    "Стохастика: методом Монте-Карло получены оценки, совпадающие с теорией в пределах статистической погрешности σ≈√(p(1-p)/N). Для редких событий (n=100, p≈1%) точность ниже — нужен больший N. Демонстрируется закон больших чисел — сходимость 1/√N.",
    "Условные вероятности: критично понимать знаменатель. P(A|B)=cntAB/cntB, а не cntAB/N. Ошибки в 2–9 раз (задачи 2 и 3) типичны.",
    "Векторизация: современный gfortran при -O3 векторизует и sum, и dot_product, и циклы, и allocatable. Сообщения -fopt-info-vec-all — главный инструмент проверки. Реальная выгода — только на больших массивах, кратных размеру вектора и выровненных. Это не многопоточность, а параллелизм данных внутри ядра.",
    "Подготовка к ЛР 2–3: последовательный код этой ЛР станет baseline для измерения ускорения при распараллеливании (OpenMP parallel do, reduction). Ожидаемое ускорение ≈ число ядер, тогда как векторизация дает ×4/×8 внутри ядра.",
]
for i, c in enumerate(conclusions, 1):
    p = doc.add_paragraph(f"{i}. {c}")
    p.runs[0].font.size = Pt(10)

add_para("Все 4 задания выполнены, результаты сохранены в results/ и plots/, код компилируется без warnings.", bold=True)
add_heading("Приложение А. Листинги", level=1)
add_para("Полные файлы в src/: task1_queue.f90 (85 строк), task2_dice.f90 (65 строк), task3_cards.f90 (90 строк), vectorize*.f90 (4 варианта). Пример task1 (фрагмент):", italic=True)
frag = """trials: do trial = 1, N_TRIALS
  Q(1:n) = 1_int8; Q(n+1:2*n) = -1_int8
  call shuffle_queue(Q)
  S=0
  do i=1,size(Q)
    S=S+Q(i)
    if (S>0) cycle trials
  end do
  count_ok = count_ok+1
end do trials"""
p = doc.add_paragraph()
run = p.add_run(frag)
run.font.name='Consolas'; run.font.size=Pt(8)

add_heading("Приложение Б. Логи компилятора (сокращенно)", level=1)
add_para("Полные логи — results/vectorize_logs/ (5.8 KB, 3.5 KB, 6.8 KB). Ключевое: optimized: loop vectorized using 16 byte vectors — означает успех.", italic=True)
add_heading("Приложение В. Команды сборки", level=1)
code3 = """# Сборка
make all
# или вручную
gfortran -O3 -std=f2008 -Wall -o bin/task1 src/task1_queue.f90
gfortran -O3 -std=f2008 -Wall -o bin/task2 src/task2_dice.f90
gfortran -O3 -std=f2008 -Wall -o bin/task3 src/task3_cards.f90
gfortran -O3 -fopt-info-vec-all -o bin/vec_static src/vectorize.f90 2> results/vectorize_logs/vec_static.log
# Запуск
./bin/task1 10 1000000
./bin/task2 1000000
./bin/task3 1000000
./bin/vec_big
# Sweep
for n in 1 2 5 10 20 50 100; do ./bin/task1 $n 1000000; done
# Графики
python3 /tmp/gen_plots.py"""
p = doc.add_paragraph()
run = p.add_run(code3)
run.font.name='Consolas'; run.font.size=Pt(8)

add_heading("Библиография", level=1)
bib = [
    "1. Гнеденко Б.В. Курс теории вероятностей. 8-е изд. М.: Едиториал УРСС, 2005. 448 с. — стр. 39–40 (очередь), стр. 55–56 (условная вероятность, карты).",
    "2. Роби Р., Замора Д. Параллельные и высокопроизводительные вычисления / пер. Логунов А.В. М.: ДМК Пресс, 2021. 800 с. — стр. 236 (SIMD, векторизация).",
    "3. Документация GCC/gfortran: gfortran --help, info gfortran, опции -O3 -fopt-info-vec-all -march=native.",
    "4. Методичка ЛР №1 (01.pdf, 5 стр.)."
]
for b in bib:
    p = doc.add_paragraph(b)
    p.runs[0].font.size = Pt(9)

# Save
doc.save(str(report_dir/"Report_LR1.docx"))
print("DOCX saved")

