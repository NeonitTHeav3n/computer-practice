import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
import pathlib
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False

outdir = pathlib.Path("/home/user/LR1_full/plots")
outdir.mkdir(parents=True, exist_ok=True)

# === Plot 1: Task1 sweep n vs p ===
import csv
ns, p_the, p_hat = [],[],[]
with open("/home/user/LR1_full/results/task1_sweep.csv") as f:
    r=csv.DictReader(f)
    for row in r:
        ns.append(int(row['n']))
        p_the.append(float(row['p_theory']))
        p_hat.append(float(row['p_hat']))

fig, ax = plt.subplots(figsize=(8,5))
ax.plot(ns, p_the, 'o-', label='Теория 1/(n+1)', linewidth=2, markersize=6, color='#1f77b4')
ax.plot(ns, p_hat, 's--', label='Моделирование (N=1e6)', linewidth=2, markersize=6, color='#ff7f0e')
ax.set_xlabel('n (половина очереди)', fontsize=11)
ax.set_ylabel('Вероятность p', fontsize=11)
ax.set_title('Задание 1: Теория vs Моделирование\np = P(никто не ждет сдачи)', fontsize=12)
ax.set_xscale('log')
ax.set_yscale('log')
ax.grid(True, which='both', linestyle='--', alpha=0.5)
ax.legend()
# annotate
for i, n in enumerate(ns):
    ax.annotate(f"{p_hat[i]:.4f}", (n, p_hat[i]), textcoords="offset points", xytext=(0,6), ha='center', fontsize=8)
plt.tight_layout()
plt.savefig(outdir/"task1_sweep.png", dpi=200)
plt.savefig(outdir/"task1_sweep.pdf")
plt.close()
print("task1_sweep done")

# === Plot 2: Task1 convergence ===
Ns, p_hats, p_th = [],[],[]
with open("/home/user/LR1_full/results/task1_convergence.csv") as f:
    r=csv.DictReader(f)
    for row in r:
        Ns.append(int(row['N']))
        p_hats.append(float(row['p_hat']))
        p_th.append(float(row['p_theory']))

fig, ax = plt.subplots(figsize=(8,5))
ax.plot(Ns, p_hats, 'o-', label='p_hat (n=10)', color='#d62728', linewidth=2)
ax.axhline(p_th[0], color='#1f77b4', linestyle='--', linewidth=2, label=f"Теория 1/11 = {p_th[0]:.5f}")
# fill error band +- 3 sigma
import math
for i, N in enumerate(Ns):
    sigma = math.sqrt(p_th[0]*(1-p_th[0])/N)
    ax.fill_between([N], [p_th[0]-3*sigma], [p_th[0]+3*sigma], color='#1f77b4', alpha=0.15)

ax.set_xscale('log')
ax.set_xlabel('Число испытаний N (лог шкала)', fontsize=11)
ax.set_ylabel('Оценка p', fontsize=11)
ax.set_title('Задание 1: Сходимость оценки p (n=10)\nЗакон больших чисел', fontsize=12)
ax.grid(True, which='both', linestyle='--', alpha=0.5)
ax.legend()
plt.tight_layout()
plt.savefig(outdir/"task1_convergence.png", dpi=200)
plt.savefig(outdir/"task1_convergence.pdf")
plt.close()
print("task1_convergence done")

# === Plot 3: Task2 comparison ===
# read last line of task2_convergence
with open("/home/user/LR1_full/results/task2_convergence.csv") as f:
    rows=list(csv.DictReader(f))
    last=[r for r in rows if r['N']=='1000000'][0] if any(r['N']=='1000000' for r in rows) else rows[-1]
labels=['P(B)\nчетная сумма','P(A)\nсумма=8','P(A|B)\nсумма=8|четная']
theory=[float(last['pB_theory']), float(last['pA_theory']), float(last['pCond_theory'])]
hat=[float(last['pB_hat']), float(last['pA_hat']), float(last['pCond_hat'])]
x=[0,1,2]
fig, ax=plt.subplots(figsize=(8,5))
w=0.35
bars1=ax.bar([p - w/2 for p in x], theory, w, label='Теория', color='#1f77b4', edgecolor='black')
bars2=ax.bar([p + w/2 for p in x], hat, w, label='Моделирование (N=1e6)', color='#ff7f0e', edgecolor='black')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_ylabel('Вероятность', fontsize=11)
ax.set_title('Задание 2: Две кости — теория vs моделирование', fontsize=12)
ax.set_ylim(0, max(theory+hat)*1.3)
for bar in bars1+bars2:
    h=bar.get_height()
    ax.annotate(f"{h:.4f}", xy=(bar.get_x()+bar.get_width()/2, h), xytext=(0,3), textcoords="offset points", ha='center', fontsize=9)
ax.legend()
ax.grid(axis='y', linestyle='--', alpha=0.4)
plt.tight_layout()
plt.savefig(outdir/"task2_comparison.png", dpi=200)
plt.savefig(outdir/"task2_comparison.pdf")
plt.close()
print("task2 done")

# === Plot 4: Task3 comparison ===
with open("/home/user/LR1_full/results/task3_convergence.csv") as f:
    rows=list(csv.DictReader(f))
    last=[r for r in rows if r['N']=='1000000'][0] if any(r['N']=='1000000' for r in rows) else rows[-1]
labels3=['P(A)\n2-я туз','P(AB)\nобе тузы','P(A|B)\n2-я туз|1-я туз']
theory3=[float(last['pA_theory']), float(last['pAB_theory']), float(last['pCond_theory'])]
hat3=[float(last['pA_hat']), float(last['pAB_hat']), float(last['pCond_hat'])]
fig, ax=plt.subplots(figsize=(8,5))
bars1=ax.bar([p - w/2 for p in x], theory3, w, label='Теория', color='#2ca02c', edgecolor='black')
bars2=ax.bar([p + w/2 for p in x], hat3, w, label='Моделирование (N=1e6)', color='#ff7f0e', edgecolor='black')
ax.set_xticks(x)
ax.set_xticklabels(labels3)
ax.set_ylabel('Вероятность', fontsize=11)
ax.set_title('Задание 3: Колода 36 карт — теория vs моделирование\nДемонстрация P(A|B) != P(AB)', fontsize=12)
ax.set_ylim(0, max(theory3+hat3)*1.4)
for bar in bars1+bars2:
    h=bar.get_height()
    ax.annotate(f"{h:.4f}", xy=(bar.get_x()+bar.get_width()/2, h), xytext=(0,3), textcoords="offset points", ha='center', fontsize=9)
ax.legend()
ax.grid(axis='y', linestyle='--', alpha=0.4)
# add annotation for difference
ax.annotate('P(A|B) в 9 раз больше P(AB)!', xy=(1.5, 0.05), xycoords='data', fontsize=9, color='red',
            bbox=dict(boxstyle="round,pad=0.3", fc="yellow", alpha=0.3), ha='center')
plt.tight_layout()
plt.savefig(outdir/"task3_comparison.png", dpi=200)
plt.savefig(outdir/"task3_comparison.pdf")
plt.close()
print("task3 done")

# === Plot 5: Trajectory examples for task1 ===
import random
random.seed(42)
fig, axes = plt.subplots(1,2, figsize=(10,4), sharey=True)
# generate one good and one bad trajectory for n=5
def gen_trajectory(n):
    Q=[1]*n + [-1]*n
    random.shuffle(Q)
    S=0
    traj=[0]
    for q in Q:
        S+=q
        traj.append(S)
    return Q, traj

# Find examples
good=None
bad=None
for _ in range(1000):
    Q,traj=gen_trajectory(7)
    is_good=all(s<=0 for s in traj[1:])
    if is_good and good is None:
        good=(Q,traj)
    if not is_good and bad is None:
        bad=(Q,traj)
    if good and bad: break

for ax, (Q,traj), title, color in [(axes[0], good, 'Благоприятная\nникто не ждал', '#2ca02c'), (axes[1], bad, 'Неблагоприятная\nкто-то ждал сдачи', '#d62728')]:
    steps=list(range(len(traj)))
    ax.step(steps, traj, where='mid', color=color, linewidth=2)
    ax.fill_between(steps, traj, 0, step='mid', alpha=0.15, color=color)
    ax.axhline(0, color='black', linewidth=1)
    ax.set_xlabel('Номер покупателя k', fontsize=10)
    ax.set_title(title, fontsize=11, color=color)
    ax.grid(True, linestyle='--', alpha=0.4)
    ax.set_ylim(-8,3)
    # annotate Q
    seq = ''.join(['+1' if q==1 else '-1' for q in Q[:7]]) # short
    ax.set_xticks(range(len(traj)))
axes[0].set_ylabel('Накопленная сумма S_k', fontsize=10)
fig.suptitle('Задание 1: Примеры траекторий (n=7, 2n=14)  — иллюстрация к рис.1 методички', fontsize=11)
plt.tight_layout(rect=[0,0,1,0.96])
plt.savefig(outdir/"task1_trajectories.png", dpi=200)
plt.savefig(outdir/"task1_trajectories.pdf")
plt.close()
print("trajectories done")

# === Plot 6: Vectorization timing ===
# parse vec_big.out for timings
# we know timings from earlier, but create bar
labels_vec=['sum(a*b)','dot_product','loop']
# get from last run file
import re
timings=[]
with open("/home/user/LR1_full/results/vectorize_logs/vec_big.out") as f:
    txt=f.read()
    for line in txt.splitlines():
        m=re.search(r"time\s+([0-9.]+)", line)
        if m and len(timings)<3:
            timings.append(float(m.group(1)))
if len(timings)<3:
    timings=[0.00129,0.001587,0.001535]
fig, ax=plt.subplots(figsize=(7,4))
bars=ax.bar(labels_vec, timings, color=['#1f77b4','#ff7f0e','#2ca02c'], edgecolor='black')
ax.set_ylabel('Время (сек)', fontsize=11)
ax.set_title('Задание 4: Время выполнения на N=1 000 000\n(O3, векторизация включена)', fontsize=12)
for bar, t in zip(bars, timings):
    ax.annotate(f"{t:.6f} c", xy=(bar.get_x()+bar.get_width()/2, bar.get_height()), xytext=(0,3), textcoords="offset points", ha='center', fontsize=9)
ax.grid(axis='y', linestyle='--', alpha=0.4)
plt.tight_layout()
plt.savefig(outdir/"vectorize_timing.png", dpi=200)
plt.savefig(outdir/"vectorize_timing.pdf")
plt.close()
print("vec timing done")

print("All plots done")
