# Лабораторная работа №1 — Полный комплект

**Тема:** Моделирование стохастических событий + векторизация (Fortran, SIMD)  
**Выполнено:** 11 октября 2026, Москва  
**Компилятор:** GNU Fortran 14.2.0, флаги `-O3 -std=f2008 -Wall -fopt-info-vec-all`

## Структура директории

```
LR1_full/
├── README.md                    ← этот файл
├── Makefile                     ← сборка всех заданий
├── src/                         ← исходные коды Fortran
│   ├── task1_queue.f90          ← Задание 1: очередь (2n, int8, shuffle)
│   ├── task2_dice.f90           ← Задание 2: две кости
│   ├── task3_cards.f90          ← Задание 3: колода 36 карт
│   ├── vectorize.f90            ← Задание 4.1: статика sum/dot_product
│   ├── vectorize_loop.f90       ← Задание 4.2: ручной цикл
│   ├── vectorize_alloc.f90      ← Задание 4.3: динамика allocatable
│   └── vectorize_big.f90        ← Задание 4.4: большой массив 1e6 (доп.)
├── bin/                         ← скомпилированные бинарники (make)
│   ├── task1, task2, task3
│   └── vec_static, vec_loop, vec_alloc, vec_big
├── results/                     ← результаты прогонов
│   ├── task1_sweep.txt          ← сырой вывод sweep по n
│   ├── task1_sweep.csv          ← таблица n vs p_theory vs p_hat
│   ├── task1_convergence.csv    ← сходимость при n=10, N=1k..2M
│   ├── task2.txt                ← вывод Задания 2
│   ├── task2_convergence.csv
│   ├── task3.txt
│   ├── task3_convergence.csv
│   └── vectorize_logs/
│       ├── vec_static.log       ← -fopt-info-vec-all
│       ├── vec_loop.log
│       ├── vec_alloc.log
│       ├── vec_big.log
│       ├── vec_static.out       ← вывод программы (722)
│       ├── vec_loop.out
│       ├── vec_alloc.out
│       └── vec_big.out          ← тайминги 1e6
├── plots/                       ← графики (png + pdf)
│   ├── task1_sweep.png/pdf
│   ├── task1_convergence.png/pdf
│   ├── task1_trajectories.png/pdf  ← примеры траекторий (Рис.1)
│   ├── task2_comparison.png/pdf
│   ├── task3_comparison.png/pdf
│   └── vectorize_timing.png/pdf
├── report/
│   ├── Report_LR1.md            ← полный отчет (markdown)
│   ├── Report_LR1.docx          ← отчет Word (для сдачи)
│   └── Report_LR1.pdf           ← отчет PDF (для печати)
└── docs/
    └── 01.pdf                   ← исходная методичка
```

## Быстрый старт

```bash
# 1. Сборка
make all

# 2. Запуск всех моделирований (N=1e6)
./bin/task1 10 1000000
./bin/task2 1000000
./bin/task3 1000000

# 3. Sweep по n (1,2,5,10,20,50,100)
for n in 1 2 5 10 20 50 100; do ./bin/task1 $n 1000000; done

# 4. Векторизация — посмотреть логи
cat results/vectorize_logs/vec_static.log | grep vectorized
cat results/vectorize_logs/vec_loop.log   | grep vectorized
cat results/vectorize_logs/vec_alloc.log  | grep vectorized
./bin/vec_static && ./bin/vec_loop && ./bin/vec_alloc && ./bin/vec_big

# 5. Пересобрать графики (если меняли N)
python3 /tmp/gen_plots.py  # или python3 scripts/gen_plots.py
```

## Результаты (кратко)

| Задание | Теория | Моделирование (N=1e6) | Ошибка | Вывод |
|---------|--------|------------------------|--------|-------|
| **1 (n=10)** | 0.090909 | 0.090124 | 0.00079 (0.86%) | Сходится к 1/(n+1), подтверждается |
| **1 (n=5)** | 0.166667 | 0.166276 | 0.00039 (0.23%) |  |
| **1 (n=50)** | 0.019608 | 0.018904 | 0.00070 (3.6%) |  |
| **2 P(A\|B)** | 0.277778 | 0.278210 | 0.00043 | `cntAB/cntB`, а не `/N` |
| **3 P(A)** | 0.111111 | 0.111728 | 0.00062 | Симметрия подтверждается |
| **3 P(A\|B)** | 0.085714 | 0.085718 | 0.00000 | `≠ P(AB)=0.0095` — разница в 9 раз! |
| **4 vec** | — | sum=722, dot=722, loop=722 | — | Все 3 варианта векторизованы (16 byte, 8 byte), динамика тоже векторизуется |

Подробности, таблицы, логи компилятора и ответы на 5 вопросов — в `report/Report_LR1.pdf`.

## Ключевые ответы для защиты

* **P(A\|B) в Задании 2** считается как `cntAB/cntB`, где `cntB` — число четных сумм. Если делить на `N`, получите `P(A)`, а не условную.
* **P(A\|B) в Задании 3** — это `3/35`, а не `1/105`. `P(AB)=1/105` — частота двух тузов подряд; условная в 9 раз больше.
* **Векторизация** — SIMD (одна инструкция на вектор 4×float SSE / 8×float AVX). Флаг `-O3` включает ее. Логи `optimized: loop vectorized using 16 byte vectors` означают успех. Все 3 варианта (sum, цикл, allocatable) векторизуются в gfortran 14; на N=7 тоже векторизуется (SLP), но выгодна только на больших массивах (N≥1000).
* **Статика vs динамика:** динамика тоже векторизуется, но может потребовать `contiguous`/`aligned` для гарантии.

## Автор

Сгенерировано автоматически как полный комплект для сдачи ЛР №1. Код комментирован, соответствует методичке (hint с `int8`, `merge`, `shuffle_queue`, `shuffle_deck`, `cycle loop1`).
