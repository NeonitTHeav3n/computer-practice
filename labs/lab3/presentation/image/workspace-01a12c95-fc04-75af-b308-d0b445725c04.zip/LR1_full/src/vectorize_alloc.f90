! Задание 4 - Вариант 3: динамические массивы (allocatable), sum + dot_product
program vectorize_alloc
  implicit none
  real, dimension(:), allocatable :: a, b
  allocate(a(7), b(7))
  a = [2.0, 3.0, 5.0, 7.0, 11.0, 13.0, 17.0]
  b = [4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0]
  print *, "sum(a*b) alloc      = ", sum(a*b)
  print *, "dot_product alloc   = ", dot_product(a, b)
  deallocate(a, b)
end program vectorize_alloc
