!===============================================================================
! Лабораторная работа №1 - Задание 2
! Две игральные кости: P(сумма=8 | сумма четная)
!
! Аналитика:
!   P(A) = P(сумма=8) = 5/36 = 0.138888...  (2+6,3+5,4+4,5+3,6+2)
!   P(B) = P(сумма четная) = 18/36 = 1/2
!   P(A|B) = P(AB)/P(B) = (5/36)/(1/2) = 5/18 = 0.277777...
!   AB = A (т.к. 8 четное)
!
! Моделирование: генерируем N пар (d1,d2) в [1,6], считаем
!   cntB  = число четных сумм
!   cntAB = число сумм == 8 (и четных автоматически)
!   P(A|B)_hat = cntAB / cntB   (ВАЖНО: делим не на N!)
!   P(A)_hat   = cntAB / N
!   P(B)_hat   = cntB  / N
!
! Компиляция: gfortran -O3 -std=f2008 -o task2 task2_dice.f90
! Запуск: ./task2 [N_trials]
!===============================================================================
program dice_task2
  use iso_fortran_env
  implicit none
  integer(int64) :: N
  integer(int64) :: i, cntB, cntAB
  integer :: d1, d2, s, ios, arg_len
  real :: u1, u2
  character(len=32) :: arg
  real(real64) :: pA_hat, pB_hat, pCond_hat
  real(real64), parameter :: pA_theory = 5.0_real64/36.0_real64
  real(real64), parameter :: pB_theory = 0.5_real64
  real(real64), parameter :: pCond_theory = 5.0_real64/18.0_real64
  integer(int64) :: t_start, t_end, t_rate

  N = 1000000_int64
  if (command_argument_count() >= 1) then
    call get_command_argument(1, arg, arg_len, ios)
    if (ios == 0) read(arg(1:arg_len), *, iostat=ios) N
  end if

  cntB = 0; cntAB = 0
  call random_seed()
  call system_clock(t_start, t_rate)

  do i = 1, N
    call random_number(u1)
    call random_number(u2)
    ! random_number дает [0,1), floor(6*u) в [0,5], +1 => [1,6]
    d1 = 1 + int(6.0 * u1)
    d2 = 1 + int(6.0 * u2)
    ! Защита от краевых эффектов (на случай u=1.0 из-за округления)
    if (d1 < 1) d1 = 1; if (d1 > 6) d1 = 6
    if (d2 < 1) d2 = 1; if (d2 > 6) d2 = 6
    s = d1 + d2
    if (mod(s, 2) == 0) then
      cntB = cntB + 1
      if (s == 8) cntAB = cntAB + 1
    end if
  end do

  call system_clock(t_end)

  pB_hat    = real(cntB, real64) / real(N, real64)
  pA_hat    = real(cntAB, real64) / real(N, real64)
  pCond_hat = 0.0_real64
  if (cntB > 0) pCond_hat = real(cntAB, real64) / real(cntB, real64)

  print '(A)', "============================================================"
  print '(A)', " Задание 2: Две игральные кости"
  print '(A)', "============================================================"
  print '(A,I0)', " Число испытаний N        = ", N
  print '(A)',   "------------------------------------------------------------"
  print '(A,I0)', " Четных сумм (B)          = ", cntB
  print '(A,I0)', " Сумм == 8 (AB)           = ", cntAB
  print '(A)',   "------------------------------------------------------------"
  print '(A,F10.6,A,F10.6)', " P(B)      теория 0.500000  hat ", pB_hat
  print '(A,F10.6,A,F10.6)', " P(A)      теория 0.138889  hat ", pA_hat
  print '(A,F10.6,A,F10.6)', " P(A|B)    теория 0.277778  hat ", pCond_hat
  print '(A)',   "------------------------------------------------------------"
  print '(A,F10.6)', " Ошибка P(A|B)            = ", abs(pCond_hat - pCond_theory)
  print '(A,F8.4,A)', " Время                    = ", real(t_end-t_start,real64)/real(t_rate,real64), " сек"
  print '(A)', "============================================================"
  print '(A)', " Примечание: P(A|B) = cntAB/cntB, а не cntAB/N !"
  print '(A)', "============================================================"

end program dice_task2
