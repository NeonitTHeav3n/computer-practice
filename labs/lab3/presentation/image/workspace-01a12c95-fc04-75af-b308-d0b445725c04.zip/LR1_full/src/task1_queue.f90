!===============================================================================
! Лабораторная работа №1 - Задание 1
! Очередь у театральной кассы (Задача о баллотировке, числа Каталана)
!
! Условие: 2n человек, n с 1 руб., n с 50 коп., билет 50 коп., в кассе 0 руб.
! Вероятность p = 1/(n+1) что никто не будет ждать сдачу.
!
! Интерпретация: +1 = покупатель с 1 руб. (нужна сдача)
!                -1 = покупатель с 50 коп. (несет размен)
! Траектория S_k = sum_{i=1..k} Q_i должна быть <= 0 для всех k (ниже Ox)
!
! Метод Монте-Карло: генерируем N случайных перестановок очереди, считаем долю
! благоприятных. Используется int8 для экономии памяти (как в методичке).
! Компиляция: gfortran -O3 -std=f2008 -o task1 task1_queue.f90
! Запуск: ./task1 [n] [N_trials]   (по умолчанию n=10, N=1000000)
!===============================================================================
program queue_task1
  use iso_fortran_env
  implicit none
  integer(int64) :: N_TRIALS
  integer :: n
  integer(int8), allocatable :: Q(:)
  integer(int64) :: trial, count_ok
  integer :: i, S, arg_len, ios
  character(len=32) :: arg
  real(real64) :: p_hat, p_theory, abs_err, rel_err
  integer(int64) :: t_start, t_end, t_rate

  ! --- Параметры по умолчанию ---
  n = 10
  N_TRIALS = 1000000_int64

  ! --- Чтение аргументов командной строки ---
  if (command_argument_count() >= 1) then
    call get_command_argument(1, arg, arg_len, ios)
    if (ios == 0) read(arg(1:arg_len), *, iostat=ios) n
  end if
  if (command_argument_count() >= 2) then
    call get_command_argument(2, arg, arg_len, ios)
    if (ios == 0) read(arg(1:arg_len), *, iostat=ios) N_TRIALS
  end if

  if (n <= 0 .or. n > 10000) then
    print *, "Ошибка: n должен быть 1..10000"
    stop 1
  end if

  allocate(Q(2*n))
  count_ok = 0

  call random_seed()
  call system_clock(t_start, t_rate)

  trials: do trial = 1, N_TRIALS
    ! Заполнение: n единиц (+1) и n минус единиц (-1)
    do i = 1, 2*n
      if (i <= n) then
        Q(i) = 1_int8
      else
        Q(i) = -1_int8
      end if
    end do

    call shuffle_queue(Q)

    ! Проверка траектории: S_k <= 0 для всех k
    S = 0
    do i = 1, size(Q)
      S = S + Q(i)
      if (S > 0) cycle trials   ! прием из методички: пропуск шага внешнего цикла
    end do
    ! Если ни разу не вышли выше 0 и S конечное =0 (автоматически, т.к. поровну +-1)
    count_ok = count_ok + 1
  end do trials

  call system_clock(t_end)

  p_hat    = real(count_ok, real64) / real(N_TRIALS, real64)
  p_theory = 1.0_real64 / real(n + 1, real64)
  abs_err  = abs(p_hat - p_theory)
  if (p_theory > 0) then
    rel_err = abs_err / p_theory * 100.0_real64
  else
    rel_err = 0.0_real64
  end if

  print '(A)', "============================================================"
  print '(A)', " Задание 1: Очередь у кассы (2n человек, n с 1 руб.)"
  print '(A)', "============================================================"
  print '(A,I0)', " n (половина очереди)     = ", n
  print '(A,I0)', " Длина очереди 2n         = ", 2*n
  print '(A,I0)', " Число испытаний N        = ", N_TRIALS
  print '(A)',   "------------------------------------------------------------"
  print '(A,I0)', " Благоприятных исходов     = ", count_ok
  print '(A,F12.8)', " p_hat (моделирование)    = ", p_hat
  print '(A,F12.8)', " p_theory = 1/(n+1)       = ", p_theory
  print '(A,F12.8)', " Абс. погрешность         = ", abs_err
  print '(A,F8.4,A)', " Отн. погрешность         = ", rel_err, " %"
  print '(A,F8.4,A)', " Время выполнения         = ", real(t_end - t_start, real64)/real(t_rate, real64), " сек"
  print '(A)', "============================================================"

contains

  !---------------------------------------------------------------------------
  ! Перемешивание Фишера-Йетса (2 прохода как в методичке)
  ! Перемещает элементы массива in-place без доп. памяти
  !---------------------------------------------------------------------------
  subroutine shuffle_queue(Q)
    integer(int8), dimension(:), intent(inout) :: Q
    integer(int8) :: itemp
    real :: u
    integer :: i, j, m, nn, k
    nn = 1
    m  = size(Q)
    do k = 1, 2
      do i = 1, m
        call random_number(u)
        j = nn + floor((m + 1 - nn) * u)   ! j в [1, m]
        itemp = Q(j)
        Q(j)  = Q(i)
        Q(i)  = itemp
      end do
    end do
  end subroutine shuffle_queue

end program queue_task1
