!===============================================================================
! Лабораторная работа №1 - Задание 3
! Колода 36 карт, вынимают 2 карты подряд без возвращения.
!
! Аналитика (36 карт, 4 туза):
!   P(A) = P(вторая - туз) = 4/36 = 1/9 = 0.111111 (безусловная, симметрия)
!   P(B) = P(первая - туз) = 4/36 = 1/9
!   P(AB) = P(обе тузы) = (4*3)/(36*35) = 12/1260 = 1/105 = 0.009524
!           = A^2_4 / A^2_36  (число размещений)
!   P(A|B) = P(AB)/P(B) = (3*4)/(35*36) * 36/4 = 3/35 = 0.085714
!
! Важно: частота P(A|B) НЕ совпадает с частотой двух тузов подряд!
!   P(AB)_hat = cntAB / N
!   P(A|B)_hat = cntAB / cntB
!
! Реализация: колода как массив индексов 1..36, тузы на позициях 1,10,19,28
! (см. подсказку методички с character массивом, но для надежности используем
!  логический массив is_ace - избегаем проблем с UTF-8 символами мастей)
! Перемешивание - Фишер-Йетс 2 прохода, как в shuffle_queue/shuffle_deck.
!
! Компиляция: gfortran -O3 -std=f2008 -o task3 task3_cards.f90
! Запуск: ./task3 [N_trials]
!===============================================================================
program cards_task3
  use iso_fortran_env
  implicit none
  integer(int64) :: N
  integer(int64) :: trial, cntA, cntB, cntAB
  integer, allocatable :: deck(:), orig(:)
  logical, allocatable :: is_ace_orig(:)
  integer :: j, ios, arg_len
  character(len=32) :: arg
  real(real64) :: pA_hat, pAB_hat, pCond_hat
  real(real64), parameter :: pA_theory    = 4.0_real64/36.0_real64       ! 0.111111
  real(real64), parameter :: pAB_theory   = 12.0_real64/1260.0_real64    ! 0.009524
  real(real64), parameter :: pCond_theory = 3.0_real64/35.0_real64       ! 0.085714
  integer(int64) :: t_start, t_end, t_rate

  N = 1000000_int64
  if (command_argument_count() >= 1) then
    call get_command_argument(1, arg, arg_len, ios)
    if (ios == 0) read(arg(1:arg_len), *, iostat=ios) N
  end if

  allocate(orig(36), deck(36), is_ace_orig(36))
  orig = [(j, j=1,36)]
  is_ace_orig = .false.
  ! Тузы: Т♣, Т♠, Т♦, Т♥ - индексы 1,10,19,28 в массиве из методички
  is_ace_orig(1)  = .true.
  is_ace_orig(10) = .true.
  is_ace_orig(19) = .true.
  is_ace_orig(28) = .true.

  cntA = 0; cntB = 0; cntAB = 0
  call random_seed()
  call system_clock(t_start, t_rate)

  do trial = 1, N
    deck = orig
    call shuffle_int(deck)

    ! deck(1) - первая карта, deck(2) - вторая
    if (is_ace_orig(deck(2))) cntA = cntA + 1
    if (is_ace_orig(deck(1))) then
      cntB = cntB + 1
      if (is_ace_orig(deck(2))) cntAB = cntAB + 1
    end if
  end do

  call system_clock(t_end)

  pA_hat    = real(cntA, real64) / real(N, real64)
  pAB_hat   = real(cntAB, real64) / real(N, real64)
  pCond_hat = 0.0_real64
  if (cntB > 0) pCond_hat = real(cntAB, real64) / real(cntB, real64)

  print '(A)', "============================================================"
  print '(A)', " Задание 3: Колода 36 карт, 2 карты подряд"
  print '(A)', "============================================================"
  print '(A,I0)', " Число испытаний N        = ", N
  print '(A)',   "------------------------------------------------------------"
  print '(A,I0)', " Вторая - туз (A)         = ", cntA
  print '(A,I0)', " Первая - туз (B)         = ", cntB
  print '(A,I0)', " Обе тузы (AB)            = ", cntAB
  print '(A)',   "------------------------------------------------------------"
  print '(A,F10.6,A,F10.6)', " P(A)    теория 0.111111  hat ", pA_hat
  print '(A,F10.6,A,F10.6)', " P(AB)   теория 0.009524  hat ", pAB_hat
  print '(A,F10.6,A,F10.6)', " P(A|B)  теория 0.085714  hat ", pCond_hat
  print '(A)',   "------------------------------------------------------------"
  print '(A,F10.6)', " Ошибка P(A)              = ", abs(pA_hat - pA_theory)
  print '(A,F10.6)', " Ошибка P(A|B)            = ", abs(pCond_hat - pCond_theory)
  print '(A,F8.4,A)', " Время                    = ", real(t_end-t_start,real64)/real(t_rate,real64), " сек"
  print '(A)', "============================================================"
  print '(A)', " Ответ на вопрос методички: P(A|B) != P(AB) !"
  print '(A,F10.6,A,F10.6)', " P(AB)  = ", pAB_hat, "  vs  P(A|B) = ", pCond_hat
  print '(A)', "============================================================"

contains

  subroutine shuffle_int(a)
    integer, dimension(:), intent(inout) :: a
    integer :: tmp, i, j, m, nn, k
    real :: u
    nn = 1; m = size(a)
    do k = 1, 2
      do i = 1, m
        call random_number(u)
        j = nn + floor((m + 1 - nn) * u)
        tmp = a(j); a(j) = a(i); a(i) = tmp
      end do
    end do
  end subroutine shuffle_int

end program cards_task3
