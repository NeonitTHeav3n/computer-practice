! Задание 4 - Вариант 4: большой массив для демонстрации выгоды векторизации
! N=1_000_000, сравнение времени sum/dot_product vs цикл
program vectorize_big
  use iso_fortran_env
  implicit none
  integer, parameter :: N = 1000000
  real, dimension(N) :: a, b
  real :: s1, s2, s3
  integer :: i
  integer(int64) :: t1, t2, rate
  real(real64) :: elapsed

  ! Заполнение случайными числами
  call random_seed()
  call random_number(a)
  call random_number(b)
  a = a * 100.0
  b = b * 100.0

  call system_clock(count_rate=rate)

  ! Вариант 1: sum(a*b)
  call system_clock(t1)
  s1 = sum(a*b)
  call system_clock(t2)
  elapsed = real(t2-t1, real64)/real(rate, real64)
  print '(A,ES15.6,A,F10.6,A)', " sum(a*b)     = ", real(s1,8), "  time ", elapsed, " sec"

  ! Вариант 2: dot_product
  call system_clock(t1)
  s2 = dot_product(a, b)
  call system_clock(t2)
  elapsed = real(t2-t1, real64)/real(rate, real64)
  print '(A,ES15.6,A,F10.6,A)', " dot_product  = ", real(s2,8), "  time ", elapsed, " sec"

  ! Вариант 3: цикл
  call system_clock(t1)
  s3 = 0.0
  do i = 1, N
    s3 = s3 + a(i)*b(i)
  end do
  call system_clock(t2)
  elapsed = real(t2-t1, real64)/real(rate, real64)
  print '(A,ES15.6,A,F10.6,A)', " loop         = ", real(s3,8), "  time ", elapsed, " sec"

  print '(A)', "Все три результата должны совпасть (с погрешностью float)."
end program vectorize_big
