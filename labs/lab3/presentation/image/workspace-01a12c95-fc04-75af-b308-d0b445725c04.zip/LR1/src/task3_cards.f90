program cards_task3
  use iso_fortran_env
  implicit none
  integer(int64), parameter :: N = 1000000_int64
  integer(int64) :: trial, cntA=0, cntB=0, cntAB=0
  integer, allocatable :: deck(:), orig(:)
  logical, allocatable :: is_ace_orig(:)
  integer :: j
  ! 36 карт, 4 туза на позициях 1,10,19,28
  allocate(orig(36), deck(36), is_ace_orig(36))
  orig = [(j, j=1,36)]
  is_ace_orig = .false.
  is_ace_orig(1)=.true.; is_ace_orig(10)=.true.; is_ace_orig(19)=.true.; is_ace_orig(28)=.true.

  call random_seed()
  do trial=1,N
    deck = orig
    call shuffle_int(deck)
    ! вторая карта - туз?
    if (is_ace_orig(deck(2))) cntA = cntA + 1
    if (is_ace_orig(deck(1))) then
      cntB = cntB + 1
      if (is_ace_orig(deck(2))) cntAB = cntAB + 1
    end if
  end do
  print '(A,F9.6,A,F9.6)', "P(A)   theory 0.111111 hat ", real(cntA,real64)/real(N,real64)
  print '(A,F9.6,A,F9.6)', "P(AB)  theory 0.009524 hat ", real(cntAB,real64)/real(N,real64)
  if(cntB>0) print '(A,F9.6,A,F9.6)', "P(A|B) theory 0.085714 hat ", real(cntAB,real64)/real(cntB,real64)

contains
  subroutine shuffle_int(a)
    integer, dimension(:), intent(inout) :: a
    integer :: tmp, i,j,m,n,k
    real :: u
    n=1; m=size(a)
    do k=1,2
      do i=1,m
        call random_number(u)
        j = n + floor((m+1-n)*u)
        tmp=a(j); a(j)=a(i); a(i)=tmp
      end do
    end do
  end subroutine
end program
