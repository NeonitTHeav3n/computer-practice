program dice_task2
  use iso_fortran_env
  implicit none
  integer(int64), parameter :: N = 1000000_int64
  integer(int64) :: i, cntB=0, cntAB=0
  integer :: d1,d2,s
  real :: u1,u2
  real(real64) :: pA_hat, pB_hat, pCond_hat

  call random_seed()
  do i=1,N
    call random_number(u1); call random_number(u2)
    d1 = 1 + int(6*u1)
    d2 = 1 + int(6*u2)
    ! защита от 0
    if (d1<1) d1=1; if(d1>6) d1=6
    if (d2<1) d2=1; if(d2>6) d2=6
    s = d1+d2
    if (mod(s,2)==0) then
      cntB = cntB + 1
      if (s==8) cntAB = cntAB + 1
    end if
  end do
  pB_hat = real(cntB, real64)/real(N, real64)
  pA_hat = real(cntAB, real64)/real(N, real64)
  pCond_hat = 0; if(cntB>0) pCond_hat = real(cntAB, real64)/real(cntB, real64)
  print '(A,F8.5,A,F8.5)', "P(B) theory 0.50000  hat ", pB_hat
  print '(A,F8.5,A,F8.5)', "P(A) theory 0.13889  hat ", pA_hat
  print '(A,F8.5,A,F8.5)', "P(A|B) theory 0.27778 hat ", pCond_hat
end program
