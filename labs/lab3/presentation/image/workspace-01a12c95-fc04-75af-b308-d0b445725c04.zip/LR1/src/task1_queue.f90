program queue_task1
  use iso_fortran_env
  implicit none
  integer(int64), parameter :: N_TRIALS = 1000000_int64
  integer, parameter :: n = 10
  integer(int8), allocatable :: Q(:)
  integer(int64) :: trial, count_ok = 0
  integer :: i, S
  logical :: ok
  real(real64) :: p_hat, p_theory

  allocate(Q(2*n))
  call random_seed()

  trials: do trial = 1, N_TRIALS
    do i = 1, 2*n
      if (i <= n) then
        Q(i) = 1_int8
      else
        Q(i) = -1_int8
      end if
    end do
    call shuffle_queue(Q)
    S = 0; ok = .true.
    do i = 1, size(Q)
      S = S + Q(i)
      if (S > 0) then
        ok = .false.
        cycle trials
      end if
    end do
    if (ok) count_ok = count_ok + 1
  end do trials

  p_hat = real(count_ok, real64) / real(N_TRIALS, real64)
  p_theory = 1.0_real64 / real(n+1, real64)
  print '(A,I0)', "n = ", n
  print '(A,I0)', "Trials = ", N_TRIALS
  print '(A,F10.6,A,F10.6)', "p_theory = ", p_theory, "  p_hat = ", p_hat
  print '(A,F10.6)', "abs error = ", abs(p_hat-p_theory)

contains
  subroutine shuffle_queue(Q)
    integer(int8), dimension(:), intent(inout) :: Q
    integer(int8) :: itemp
    real :: u
    integer :: i,j,m, nn, k
    nn = 1; m = size(Q)
    do k=1,2
      do i=1,m
        call random_number(u)
        j = nn + floor((m+1-nn)*u)
        itemp = Q(j); Q(j) = Q(i); Q(i) = itemp
      end do
    end do
  end subroutine
end program
